# MGP-6 v4.3 private-data audit

## Result: private assets are protected in an ignored local boundary

- Private hidden inputs, hidden gold, final human gold, and private audit assets
  were extracted only under `.private/benchmarks/mgp6/v4.3/`.
- `git check-ignore -v` confirms that representative hidden-input, hidden-gold,
  human-gold, mapping, annotation, and audit paths are covered by the exact
  `.gitignore` rule on line 40.
- No private record content was printed, committed, indexed, or passed to a
  model. A local split-map SHA-256 was recorded for future freeze control; the
  split map itself was not exposed.
- The subsequently completed provider smoke and public-dev run used only public
  train/dev records. Their ignored logs and manifests record
  `hidden_gold_accessed=false`; neither run opened private inputs or gold.
- The committed deterministic rules-controller dev run likewise used only the
  public dev split; its ignored prediction, raw-response, manifest, and public
  metric files are covered by the existing `runs/` ignore rule.
- The subsequent model-backed B1 public-dev run used only
  `benchmarks/mgp6/mgp6_v4_3/public/dev.jsonl`; its ignored prediction,
  raw-response, manifest, and public metric files record
  `hidden_gold_accessed=false`.
- The subsequent model-backed B2--B4 public-dev runs likewise used only that
  public development file. Their ignored artifacts record
  `hidden_gold_accessed=false`; no private component map was read by their
  public scoring.
- The tracked public prompt template and loader contain no prohibited private
  keys; ignored fixture and provider-run logs contain public IDs and model
  responses only, with no private fields.

## Blocking protection gap

The narrow rule is `.private/benchmarks/mgp6/v4.3/`. It was added before private
extraction and verified before and after extraction. `DO_NOT_COMMIT.md` explains
the local boundary but is intentionally ignored with the directory.

## Required follow-up audit

After protection is added and private packages are placed, verify every private
file is ignored, scan non-private model-facing files for prohibited keys
(`gold_action`, `design_target`, `source_item_id`, `component_id`,
`private_item_id`, `annotator_id`, and `final_consensus`), and fail the
integration if any prohibited field is found.
